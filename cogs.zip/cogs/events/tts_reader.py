# cogs/tts_reader.py

import discord
from discord.ext import commands
from gtts import gTTS
import asyncio
import os

class TTSReader(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    

    @commands.command(name="leavevc")
    async def leave_voice(self, ctx):
        """Bot rời voice channel"""
        if ctx.voice_client:
            await ctx.voice_client.disconnect()
            await ctx.send("Đã rời khỏi voice channel.")

    @commands.command(name="d")
    async def speak(self, ctx, *, message: str):
        """Bot đọc tin nhắn"""
        vc = ctx.voice_client
        if not vc or not vc.is_connected():
            await ctx.send("❌ Bot chưa vào voice channel. Dùng `!joinvc` trước.")
            return

        if vc.is_playing():
            await ctx.send("")
            return

        # Giới hạn độ dài tin nhắn
        if len(message) > 200:
            await ctx.send("⚠️ Tin nhắn quá dài, vui lòng rút gọn dưới 200 ký tự.")
            return

        # Chuyển text thành âm thanh
        try:
            tts = gTTS(text=message, lang="vi")
            tts.save("temp.mp3")

            vc.play(discord.FFmpegPCMAudio("temp.mp3"),
                    after=lambda e: os.remove("temp.mp3"))

            await ctx.message.add_reaction("🔊")

            while vc.is_playing():
                await asyncio.sleep(0.5)

        except Exception as e:
            await ctx.send(f"❌ Lỗi khi đọc: {e}")

async def setup(bot):
    await bot.add_cog(TTSReader(bot))
